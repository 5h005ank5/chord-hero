# Superpowers Background Asset Pack (part 1)

This asset pack was created by Pixel-boy.
Please do not redistribute it.

You can use any and all of the assets found in this package in your own games,
even commercial ones. Attribution is not required but appreciated.
Placing a link to https://www.patreon.com/SparklinLabs?ty=h somewhere would be awesome :)

Download Superpowers, the HTML5 2D+3D game maker
and more asset packs over at https://sparklinlabs.itch.io/superpowers

Enjoy!
- Sparklin Labs
